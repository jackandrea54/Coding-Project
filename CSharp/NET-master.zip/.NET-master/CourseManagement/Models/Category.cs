﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CourseManagement.Models
{
    public partial class Category
    {
        public int CId { get; set; }
        public string CDescription { get; set; }
    }
}
