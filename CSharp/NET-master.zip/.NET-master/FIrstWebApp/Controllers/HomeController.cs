﻿// using FIrstWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace FIrstWebApp.Controllers
{
    public class HomeController : Controller
    {
        // public string Index()
        // {
        //     return $"Controller: Home, Action:Index";
        // }
        // public IActionResult List()
        // {
        //     List<Student> students;
        //     using (var context = new LAB2Context())
        //     {
        //         students = context.Students.ToList();
        //     }
        //     return View(students);

        // }
        // public void Delete()
        // {

        // }
        // public string Show(
        //     int id,
        //     string name)
        // {
        //     return $"id: {id}, name: {name}";
        // }
    }
}
