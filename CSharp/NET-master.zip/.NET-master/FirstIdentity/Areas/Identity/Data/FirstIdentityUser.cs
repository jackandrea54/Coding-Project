﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace FirstIdentity.Areas.Identity.Data
{
    // Add profile data for application users by adding properties to the FirstIdentityUser class
    public class FirstIdentityUser : IdentityUser
    {
    }
}
