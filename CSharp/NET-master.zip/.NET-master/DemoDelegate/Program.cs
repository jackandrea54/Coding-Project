﻿using System;

namespace DemoDelegate_Lambda
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DemoDelegate.DemoBasicDelegate();
        }
    }
}
