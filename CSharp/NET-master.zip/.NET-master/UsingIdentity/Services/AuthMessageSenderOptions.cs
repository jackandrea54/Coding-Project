﻿namespace UsingIdentity.Services
{
    public class AuthMessageSenderOptions
    {
        public string? SendGridKey { get; set; }
    }
}
