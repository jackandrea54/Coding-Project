﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CourseManagement.Models
{
    public partial class Study
    {
        public int SchoolId { get; set; }
        public int PupilId { get; set; }
    }
}
