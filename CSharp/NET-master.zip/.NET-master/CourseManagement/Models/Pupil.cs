﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CourseManagement.Models
{
    public partial class Pupil
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
